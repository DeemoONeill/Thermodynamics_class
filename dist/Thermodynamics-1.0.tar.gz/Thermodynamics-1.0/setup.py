# -*- coding: utf-8 -*-
"""
Created on Fri Feb 15 22:17:01 2019

@author: oneil
"""

from distutils.core import setup

setup(name='Thermodynamics',
      version='1.0',
      py_modules=['Thermodynamics'],
      )
